<?xml version="1.0" standalone="yes"?>
<coupons type="CurrentCoupons">
 
<Coupon><id>1</id><name>FreeRide</name></Coupon><Coupon><id>2</id><name>Movie Discount</name></Coupon><Coupon><id>3</id><name>free meal</name></Coupon><Coupon><id>4</id><name>GotIT</name></Coupon><Coupon><id>5</id><name>GotIT</name></Coupon><Coupon><id>6</id><name>ShayBit</name></Coupon><Coupon><id>7</id><name>Redbull</name></Coupon><Coupon><id>8</id><name>Shimon</name></Coupon><Coupon><id>9</id><name>Shay-test</name></Coupon></coupons>
