<?php
$xmlstr = <<<XML
<?xml version="1.0" standalone="yes"?>
  
<coupons>
 
</coupons>
XML;

?>