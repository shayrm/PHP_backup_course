<?php
//
//interface definition for coupon class
//
interface ICouponsDAO {

    function getCoupon($id);
    function addCoupon(Coupon $ob);
    function getCoupons($csv);
    function updateCoupon(Coupon $ob);
    
}

class CouponsPlatformDAO implements ICouponsDAO {
    var $host="localhost";
    var $user="coupon";
    var $password="LetMeIn!!!";
    var $database="coupon_db";
    
    
    function ConnectToDatabase(){
    
        //$host="localhost";
        //$user="coupon";
        //$password="LetMeIn!!!";
        //$database="coupon_db";
        
        $mysqlInet= new mysqli($this->host, $this->user, $this->password, $this->database);
    
        /* check connection */
        if (mysqli_connect_errno()) {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }
    
        return $mysqlInet;
    }
    
    function runCouponQuery ($query,$id,$csv){
    
        //use PURE CSS file
        echo "<link rel=\"shortcut icon\" href=\"bootstrap-3.0.0/assets/ico/favicon.png\">";
    
        //loading Pure CSS file
        echo "<link href=\"Coupon_CSS_file_from_Pure-min.css\" rel=\"stylesheet\">";
    
        //connect to the DB
        $mysql_connect=ConnectToDatabase();
    
        if ($stmt = $mysql_connect->prepare("$query")){
    
            /* bind parameters for id */
            if (isset($id)){
                $stmt->bind_param("i", $id);
            }
    
                 //bind the all coupon information
                //No need to bind the param since we are not using SQL query with SOMETHING=?
                // we run only simple SELECT * query
                //$stmt->bind_param("iiisss", $id,$category_id, $business_id, $name, $description, $imagefilename);
            
    
            /* execute query */
            $stmt->execute();
    
            /* bind result variables  and print it to HTML table*/
            $stmt->bind_result($id, $category_id, $business_id, $name, $description, $imagefilename);
            echo <<<END
            <div class="pure-menu pure-menu-open pure-menu-horizontal">
            <a href="#" class="pure-menu-heading">Coupon Admin</a>
    
            <ul>
                <li class="pure-menu-selected"><a href="./NewCouponCreator_Form_page.html">New Coupon</a></li>
                <li><a href="./NewBusinessCreator_Form_page.html">New Business</a></li>
                <li><a href="./NewCategoryCreator_Form_page.html">New Category</a></li>
                </ul>
            </div>
END;
    
            echo "<br>";
            echo "<hr>";
            echo <<<END
     <div class="pure-g">
        <div class="pure-u-2-5"><h2>Copun list:</h2></div>
        <div class="pure-u-2-5"><h3>The content of the Coupon table</h3></div>
     
    </div>
END;
            echo "<table class=\"pure-table pure-table-horizontal\">";
            echo "<thead><tr>";
            echo "<th>ID</th><th>Cat_id</th><th>Bus_id</th><th>coupon name</th><th>description</th><th>imagefilename</th>";
            echo "</tr></thead>";
            
            //in case there is request to export the Coupon table to CSV file;
            //adding header to the file
            if (isset($csv)){
                $file = fopen("test.csv","a+");
                fprintf($file, "ID,category_id,business_id,name, description,imagefilename \n");
                
            }
            /* fetch value */
            while($stmt->fetch()){
                //echo "<br>";
                echo "<tr>";
                printf("<td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td>",$id, $category_id, $business_id, $name, $description,$imagefilename);
                
                //incase there is a need to export the content of the Coupon table to file in CSV format
                if (isset($csv)){
                    
                    fprintf($file,"%s,%s,%s,%s,%s,%s \n",$id, $category_id, $business_id, $name, $description,$imagefilename);
                    //fputcsv($file,$ary);
                }
                echo "</tr>";
            }
            echo "</table>";
    
            /* close statement */
            $stmt->close();
           // fclose($file);
    
        }
        return;
    }
    
    function getCoupon($id) {
        // Incould the functions file to be able to connect to the DB; 
        //include 'Coupon_Function_file.php';
        
        //run mysqli via Connect to Database function.
        $query = "SELECT * FROM coupon_db.coupons where id=?";
        $this->runCouponQuery($query, $id);
        
    }
    
    function getCoupons($csv){
        
        // Incould the functions file to be able to connect to the DB;
        //include 'Coupon_Function_file.php';
        
        //run mysqli via Connect to Database function.
        //run the query to list all coupons information registered in the database
        $query="SELECT * FROM coupon_db.coupons";
        if (isset($csv)){
            $this->runCouponQuery($query,NULL,TRUE);
        }
        //in case there is no need to export to CSV file
        $this->runCouponQuery($query,NULL,NULL);
                  
    }
    
    function addCoupon(Coupon $ob){
        $ob->enterNewCoupon();
    }
    
    function updateCoupon(Coupon $ob){
        $ob->enterNewCoupon();
    }
}