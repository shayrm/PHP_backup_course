<?php
include 'CouponClassBusiness.php';
include 'CouponsPlatformDAOClass.php';
include 'CouponMySQLConnection.php';
include 'Coupon_Function_file.php';

//$query="SELECT * FROM coupon_db.coupons";
//runCouponQuery($query,NULL);

$csv=null;  
$coupunObject = new CouponsPlatformDAO;
$coupunObject->getCoupons($csv);

