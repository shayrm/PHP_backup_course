<?php

function sum($a,$b)
{
	return $a+$b;
}

$vec = get_defined_functions();
var_dump($vec);

?>