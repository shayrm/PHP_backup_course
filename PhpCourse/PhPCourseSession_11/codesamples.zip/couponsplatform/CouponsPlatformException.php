<?php
class CouponsPlatformException extends Exception 
{
	function __construct($str)
	{		
		parent::__construct($str);
	}	
}