<?php
class Coupon
{
	private $id;
	private $name;	
	private $business;
	//..	
}
?>