
<html>
<body>

    <form action="Ses5_upload_file.php" method="post" enctype="multipart/form-data">
        <label for="file">Please choose file to upload:</label>
        <input type="file" name="file_name" id="file"><br>
        <input type="submit" name="submit" value="Upload">
    </form>

</body>
</html>
<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
