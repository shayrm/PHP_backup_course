<?php
header("Location: http://www.ynet.co.il");
?>