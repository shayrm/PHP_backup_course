<?php
$vec = http_get_request_headers();
var_dump($vec);
?>