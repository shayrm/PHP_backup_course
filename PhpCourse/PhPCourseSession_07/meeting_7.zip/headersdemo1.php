<?php
header("content-type: text/plain");
echo "<h1>hello friends!</h1>";
?>