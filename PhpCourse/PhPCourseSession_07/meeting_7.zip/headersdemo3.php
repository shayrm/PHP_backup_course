<?php
header("content-type: image/gif");
echo "<h1>hello friends!</h1>";
?>