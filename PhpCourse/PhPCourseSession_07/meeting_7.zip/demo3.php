<?php
echo $_SERVER['HTTP_USER_AGENT'];
?>